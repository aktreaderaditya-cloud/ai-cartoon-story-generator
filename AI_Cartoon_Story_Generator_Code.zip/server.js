require("dotenv").config();
const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 250);
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const licenseKeys = new Set(
  (process.env.LICENSE_KEYS || "ANNU,ADITYA,ROHIT,SONU")
    .split(",").map(x => x.trim().toUpperCase()).filter(Boolean)
);

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 9)}${path.extname(file.originalname).slice(0, 10)}`)
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024 },
  fileFilter: (_req, file, cb) => file.mimetype.startsWith("video/")
    ? cb(null, true) : cb(new Error("कृपया वीडियो फ़ाइल चुनें।"))
});

app.post("/api/license", (req, res) => {
  const key = String(req.body?.key || "").trim().toUpperCase();
  if (!key) return res.status(400).json({ ok: false, message: "License Key डालें।" });
  if (!licenseKeys.has(key)) return res.status(401).json({ ok: false, message: "License Key सही नहीं है।" });
  res.json({ ok: true });
});

app.post("/api/generate", upload.single("video"), async (req, res) => {
  const key = String(req.body?.license || "").trim().toUpperCase();
  const prompt = String(req.body?.prompt || "").trim();

  if (!licenseKeys.has(key)) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(401).json({ error: "पहले सही License Key डालें।" });
  }
  if (!prompt) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: "अपना प्रॉम्प्ट लिखें।" });
  }

  // किसी provider का endpoint/schema अनुमान से नहीं भरा गया है।
  // Explorium key होना अपने आप video-generation support साबित नहीं करता।
  if (!process.env.AI_API_URL || !process.env.AI_API_KEY || process.env.AI_API_KEY === "PASTE_NEW_KEY_HERE") {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(501).json({
      error: "API अभी कॉन्फ़िगर नहीं है।",
      detail: "Provider की official documentation से video-generation endpoint, authentication और request format मिलने पर integration पूरा करें।"
    });
  }

  try {
    const headers = { "Content-Type": "application/json" };
    headers[process.env.AI_API_AUTH_HEADER || "Authorization"] =
      `${process.env.AI_API_AUTH_PREFIX ?? "Bearer"} ${process.env.AI_API_KEY}`.trim();

    const payload = { prompt };
    if (process.env.AI_MODEL) payload.model = process.env.AI_MODEL;

    // Generic JSON placeholder only. Adapt to official provider docs.
    // The uploaded video is saved locally and is not sent to the provider here.
    const response = await fetch(process.env.AI_API_URL, {
      method: "POST", headers, body: JSON.stringify(payload)
    });
    const raw = await response.text();
    let result;
    try { result = JSON.parse(raw); } catch { result = { response: raw }; }
    if (!response.ok) return res.status(502).json({ error: "AI provider request failed", status: response.status, result });
    res.json({ ok: true, message: "Provider response received. Video job/status/download handling may still need to be implemented.", result });
  } catch (err) {
    res.status(500).json({ error: err.message || "Server error" });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: `वीडियो ${MAX_UPLOAD_MB} MB से छोटा होना चाहिए।` });
  }
  res.status(400).json({ error: err.message || "Request error" });
});

app.listen(PORT, () => console.log(`Open http://localhost:${PORT}`));
