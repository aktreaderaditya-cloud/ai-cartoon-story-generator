# AI Cartoon Story Generator

## सुरक्षा
आपने API key चैट में भेजी थी। उसे exposed मानकर provider dashboard में revoke/rotate करें। नई key केवल `.env` में डालें; चैट, HTML, JavaScript या public repository में न रखें।

## चलाने के लिए
1. Node.js 18+ इंस्टॉल करें।
2. इस फ़ोल्डर में terminal खोलें और `npm install` चलाएँ।
3. `.env.example` की कॉपी `.env` नाम से बनाएँ।
4. नई API key `.env` में डालें। `AI_API_URL` और model/auth settings सिर्फ provider की official documentation के अनुसार भरें।
5. `npm start` चलाएँ।
6. Browser में `http://localhost:3000` खोलें।

## अभी क्या शामिल है
- Responsive website UI
- Demo License Key: ANNU, ADITYA, ROHIT, SONU
- Video upload form और prompt form
- Express backend का starter

## अभी क्या बाकी है
Explorium/AgentSource की API key होने से यह साबित नहीं होता कि उसमें video-generation endpoint है। यह starter किसी endpoint या schema का अनुमान नहीं लगाता। Official API docs के अनुसार request, file upload, async job polling और generated video download की integration पूरी करनी होगी। फिलहाल generate endpoint provider को reference video नहीं भेजता और अपने आप video नहीं बनाता।

Demo license codes public website के लिए सुरक्षित authentication नहीं हैं। Public launch से पहले proper accounts, sessions, rate limits, HTTPS और upload cleanup जोड़ें।

केवल ऐसे reference videos इस्तेमाल करें जिनके लिए आपके पास अनुमति हो। नई कहानी, पात्र, संवाद और visuals बनाएं; बदलाव करने से copyright-free होने की गारंटी नहीं होती।
